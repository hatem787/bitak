// 🔧 إعدادات Firebase هنا
const firebaseConfig = {
  apiKey: 'YOUR_KEY',
  authDomain: 'YOUR_PROJECT.firebaseapp.com'
};

firebase.initializeApp(firebaseConfig);